<html>
<head>
    <meta content="text/html; charset=UTF-8" http-equiv="content-type">
</head>
<body>
    <div style="float: left;margin-right: 10px;">
        <img src="cid:logo_mynotescode" alt="Logo" style="height: 50px">
    </div>

    <h2 style="margin-bottom: 0;">My Notes Code</h2>
    http://www.mynotescode.com

    <div style="clear: both"></div>
    <hr />

    <div style="text-align: justify">
        <?php echo $pesan; // Tampilkan isi pesan ?>
    </div>
</body>
</html>
